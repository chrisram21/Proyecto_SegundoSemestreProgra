/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectosegundaunidadfase1;

/**
 *
 * @author luiss
 */
public class ProyectoSegundaUnidadFase1 {

    public static void main(String[] args) {
        
        Cuentas us1 = new Cuentas("1234","admin",true);
        
        InicioDeSesion papa= new InicioDeSesion();
        papa.setVisible(true);
        
    }
}
