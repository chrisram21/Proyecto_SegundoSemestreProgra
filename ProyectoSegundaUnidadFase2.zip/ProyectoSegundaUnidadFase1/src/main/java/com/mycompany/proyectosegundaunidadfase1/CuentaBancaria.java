/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectosegundaunidadfase1;

/**
 *
 * @author luiss
 */
public class CuentaBancaria {

    private String nombres;
    private String apellidos;
    private String tel;
    private String tipo;//Monetaria/ahorro
    private String idcuenta;
    private double saldo;
    private boolean estado;
    
    //temporal inge (pa pruebas)
    public CuentaBancaria()
    {
        this.nombres = "admin";
        this.apellidos = "admin";
        this.tel = "admin";
        this.tipo = "Monetaria";
        this.estado= true;
        this.saldo=30000;
        this.idcuenta="admin-02";
    }

    public CuentaBancaria(String nom, String ape, String tel, String tipo, double saldoinicial) {
        this.nombres = nom;
        this.apellidos = ape;
        this.tel = tel;
        this.tipo = tipo;
        this.estado= true;
        this.saldo=saldoinicial;
        
        String inicioid_n = ""+nom.charAt(0)+ape.charAt(0);
        String tipoid="";
        
        if(tipo.equals("Ahorro"))
        {
            tipoid="01";
        }
        else if( tipo.equals("Monetaria"))
        {
            tipoid="02";
        }
        
        int numrand=0;
        String randoms="";
        
        for (int i = 0; i < 9; i++) {
            numrand = (int)(Math.random()*10);
            randoms= randoms+numrand;
        }

        this.idcuenta=""+inicioid_n+randoms+"-"+tipoid;
    }
    
    //voids par ver nomas que datos metimos
    public String getNombres()
    {
        return this.nombres;
    }
    
    public String getApellidos()
    {
        return this.apellidos;
    }
    
    public String getTelefono()
    {
        return this.tel;
    }
    
    public String getTipoCuenta()
    {
        return this.tipo;
    }
    
    public String getIDcuenta()
    {
        return this.idcuenta;
    }
    
    public String getSaldo()
    {
        return String.valueOf(this.saldo);
    }
    
    //void para editar cuenta
    public void setNombre(String nombre)
    {
        this.nombres=nombre;
    }
    
    public void setApellidos(String apellidos)
    {
        this.apellidos=apellidos;
    }
    
    public void setTelefono(String telefonico)
    {
        this.tel=telefonico;
    }
    
    //voids para depositar o retirar
    public void addSaldo(double monto)
    {
        this.saldo= this.saldo+monto;
    }
    
    public void subtractSaldo(double monto)
    {
        this.saldo= this.saldo-monto;
    }
    
}
