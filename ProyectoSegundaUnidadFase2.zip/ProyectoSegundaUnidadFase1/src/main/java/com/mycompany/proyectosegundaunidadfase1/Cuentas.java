/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectosegundaunidadfase1;

/**
 *
 * @author luiss
 */
public class Cuentas {
    
    private String pass;
    private String usuario;
    private boolean admin;
    
    public Cuentas()
    {
        this.pass="1234";
        this.admin=true;
        this.usuario="admin";
    }
    
    public Cuentas(String password, String usuario, boolean admin)
    {
        this.pass=password;
        this.admin=admin;
        this.usuario=usuario;
    }
    
    public String getUsuario(){
        return this.usuario;
    }
    public String getPassword(){
        return this.pass;
    }
    public boolean getAdmin()
    {
        return this.admin;
    }
    
    
}
