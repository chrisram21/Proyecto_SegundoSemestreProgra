/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectosegundaunidadfase1;

/**
 *
 * @author luiss
 */
public class CuentaBancaria {

    private String nombres;
    private String apellidos;
    private String tel;
    private String tipo;//Monetaria/ahorro
    private String idcuenta;
    private boolean estado;

    public CuentaBancaria(String nom, String ape, String tel, String tipo) {
        this.nombres = nom;
        this.apellidos = ape;
        this.tel = tel;
        this.tipo = tipo;
        
        String inicioid_n = ""+nom.charAt(0)+ape.charAt(0);
        
        this.idcuenta="";
    }

}
